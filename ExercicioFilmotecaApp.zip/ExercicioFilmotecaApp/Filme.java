import java.util.Scanner;

class Filme
{
    Scanner objetoFilme = new Scanner(System.in);
    
        String nome;
        String genero;
        Double avaliacao;
        
    Filme()
    {
 
        System.out.println("Qual sera o seu proximo filme");
        nome = "Indefenido";
        genero = "Accao";
        avaliacao = 4.5;
        
    }
    
    void informacaoCompletaFilme()
    {
        System.out.println("\nFilme: " + nome + " | Gênero: " + genero + " | Avaliacao: " + avaliacao);
    }
}